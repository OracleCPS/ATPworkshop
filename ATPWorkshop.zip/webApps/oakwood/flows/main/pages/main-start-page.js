define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.printRequest = function (request) {
    console.log("request is: ", request);
  };
  
  PageModule.prototype.unhideResults = function () {
    document.getElementById("h1--1392009567-1").style.visibility = "visible";
    document.getElementById("oj-label--1392009567-1").style.visibility = "visible";
    document.getElementById("oj-input-text--1392009567-1").style.visibility = "visible";
    document.getElementById("oj-label--1392009567-2").style.visibility = "visible";
    document.getElementById("oj-input-text--1392009567-2").style.visibility = "visible";
    document.getElementById("oj-label--1821252688-7").style.visibility = "visible";
    document.getElementById("oj-input-text--1821252688-4").style.visibility = "visible";
    document.getElementById("oj-text-area--1821252688-1").style.visibility = "visible";
  };

  return PageModule;
});
